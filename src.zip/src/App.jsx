import React from 'react'
import Header from './Header'
import Footer from './footer'
import Nav from './Nav'
import Home from './Home'

function App() {
  return (
    <>
    <Header/>
    <Nav/>
    <Footer/>
    </>
  )
}

export default App