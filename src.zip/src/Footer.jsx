import React from 'react'

function Footer() {
  return (
    <footer className='bg-dark text-white text-center p-3 mt-3'>
      <h1>
      This is footer
      </h1>
      </footer>
  )
}

export default Footer